<?php
/**
 * Plugin Name: Simple WP Ads
 * Plugin URI: https://www.ibenic.com/create-simple-wordpress-advertising-plugin-the-introduction/
 * Description: Plugin made from the tutorial on ibenic.com
 * Version: 1.0
 * Author: Igor Benic
 * Author URI: https://ibenic.com
 *
 * Text Domain: swa
 * Domain Path: /languages/
 *
 * @package Simple WP Ads
 * @author Igor Benic
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}

define( 'SWA_ROOT', plugin_dir_path( __FILE__ ) );
define( 'SWA_URI', plugin_dir_url( __FILE__ ) );

/**
 * Main Class
 */
class Simple_WP_Ads {

	/**
	 * The single instance of the class.
	 */
	protected static $_instance = null;

	/**
	 * Getting the static instance
	 * @return object 
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Load dependencies
	 * @return void 
	 */
	public function load_dependencies(){

		/**
		 * Abstracts
		 */
		require_once SWA_ROOT .'inc/abstracts/class-swa-settings.php';

		/**
		 * Classes
		 */
		require_once SWA_ROOT .'inc/class-swa-status.php';
		require_once SWA_ROOT .'inc/class-swa-metabox.php';
		
		/**
		 * Base functions
		 */
		require_once SWA_ROOT .'inc/swa-cpt.php';
		require_once SWA_ROOT .'inc/swa-statuses.php';

		/**
		 * Load only on admin side
		 */
		if( is_admin() ) {
			require_once SWA_ROOT .'inc/class-swa-metabox.php';
			add_action( 'load-post.php',     array( $this, 'construct_metabox_on_ad' ) );
        	add_action( 'load-post-new.php', array( $this, 'construct_metabox_on_ad' ) );
		}
	}

	/**
	 * Construct metabox(es) when on Ad edit/new post page
	 * @return void 
	 */
	public function construct_metabox_on_ad(){

			require_once SWA_ROOT .'inc/swa-metaboxes.php';
	}
}

function swa(){
	return Simple_WP_Ads::instance();
}

function swa_start(){
	$swa = swa();
	$swa->load_dependencies();
}

add_action( 'plugins_loaded', 'swa_start');