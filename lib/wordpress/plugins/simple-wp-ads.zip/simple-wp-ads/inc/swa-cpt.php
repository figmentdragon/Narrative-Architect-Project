<?php


function swa_cpt() {

	$labels = array(
		'name'                => _x( 'SWA', 'Post Type General Name', 'swa' ),
		'singular_name'       => _x( 'SWA', 'Post Type Singular Name', 'swa' ),
		'menu_name'           => __( 'SWA', 'swa' ),
		'parent_item_colon'   => __( 'Parent Ad:', 'swa' ),
		'all_items'           => __( 'All Ads', 'swa' ),
		'view_item'           => __( 'View Ad', 'swa' ),
		'add_new_item'        => __( 'Add New Ad', 'swa' ),
		'add_new'             => __( 'Add New', 'swa' ),
		'edit_item'           => __( 'Edit Ad', 'swa' ),
		'update_item'         => __( 'Update Ad', 'swa' ),
		'search_items'        => __( 'Search Ad', 'swa' ),
		'not_found'           => __( 'Not found', 'swa' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'swa' ),
		'featured_image'        => __( 'Ad Image', 'swa' ),
		'set_featured_image'    => __( 'Set Ad image', 'swa' ),
		'remove_featured_image' => __( 'Remove Ad image', 'swa' ),
		'use_featured_image'    => __( 'Use as Ad image', 'swa' ),
	);
	$args = array(
		'labels'              => $labels,
		'supports'            => array( 'title', 'thumbnail', ),
		'hierarchical'        => false,
		'public'              => false,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 2,
		'menu_icon'           => 'dashicons-slides',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => true,
		'publicly_queryable'  => false,
		'capability_type'     => 'page',
	);
	register_post_type( 'swa', $args );

}

// Hook into the 'init' action
add_action( 'init', 'swa_cpt', 0 );