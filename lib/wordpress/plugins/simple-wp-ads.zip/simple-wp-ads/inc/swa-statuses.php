<?php

/**
 * SWA Statuses used for CPT
 */

new SWA_Status( array(
	'post_type' => array( 'swa' ),
	'slug' => 'ended',
	'label' => _x( 'Ended', 'swa' ),
	'action' => 'update',
	'label_count' => _n_noop( 'Ended <span class="count">(%s)</span>', 'Ended <span class="count">(%s)</span>' ),
));