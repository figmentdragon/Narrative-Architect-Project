<?php

$swa_metabox = new SWA_Metabox( __( 'Ad Info'), 'swa_info', array( 'swa' ) );

$swa_metabox->add_field(
	array(
		'name' => 'duration',
		'title' => __( 'Duration of the Ad', 'swa'),
		'default' => 7,
		'desc' => __( 'Add duration in days', 'swa' )
		)
);