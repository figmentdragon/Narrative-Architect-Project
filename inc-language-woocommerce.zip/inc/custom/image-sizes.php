<?php
/**
 * Add all the Image Sizes
 * add_image_size()
*/

add_image_size( 'creativity-blogthumb', 1300, 9999, true ); //Custom Thumbnail Size call using the_post_thumbnail('creativity-blogthumb');
add_image_size( 'creativity-logo', 400, 400, true );
add_image_size( 'creativity-portfolio', 1920, 9999, true ); // Flexible Height
add_image_size( 'creativity-slider', 1920, 1080, true ); // Ratio 16:9
add_image_size( 'creativity-grid-large', 750, 750, true ); // Grid image crop
add_image_size( 'creativity-post-image', 850, 300, true ); // Post Image
add_image_size( 'creativity-bpost-image', 380, 250, true ); // Blog  Post Image
add_image_size( 'creativity-featbox-image', 580, 350, true ); // Feature Box Thumbnail
?>
